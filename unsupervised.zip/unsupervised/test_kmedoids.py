from clustering.KMedoids import KMedoids
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt


# Test kmeans algorithm with synthetic data

        
X, y = make_blobs(
    n_samples=500,
    n_features=2,
    centers=4,
    cluster_std=1,
    center_box=(-10.0, 10.0),
    shuffle=True,
    random_state=1,
)

# Create and fit KMedoids model
kmedoids = KMedoids(n_clusters=4, random_state=42)
kmedoids.fit(X)

# Get cluster labels and medoids
labels = kmedoids.labels_
medoids = kmedoids.cluster_centers_

# Plotting the medoids
plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis', label='Data Points')
plt.scatter(medoids[:, 0], medoids[:, 1], c='red', marker='X', s=200, label='Medoids')

plt.title('KMedoids Clustering Result')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.legend()
plt.show()
