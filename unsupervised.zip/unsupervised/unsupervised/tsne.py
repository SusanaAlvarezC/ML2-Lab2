import numpy as np

class TSNE:
    def __init__(self, perplexity=30, learning_rate=200, n_iter=1000):
        self.perplexity = perplexity
        self.learning_rate = learning_rate
        self.n_iter = n_iter
        self.Y = None  # Embedding space

    # rest of your class implementation...


    def fit(self, X):
        # Compute pairwise similarities using Gaussian kernel
        P = self._compute_pairwise_similarities(X)

        # Initialize low-dimensional representation randomly
        Y = np.random.randn(X.shape[0], 2)

        # Perform t-SNE optimization
        for _ in range(self.n_iter):
            Q = self._compute_pairwise_similarities(Y)
            grad = self._compute_gradient(P, Q, Y)
            Y -= self.learning_rate * grad

        self.Y = Y

    def _compute_pairwise_similarities(self, X):
        # Implement Gaussian kernel for pairwise similarities
        # You can customize this based on your preference
        sum_X = np.sum(np.square(X), axis=1)
        D = np.add(np.add(-2 * np.dot(X, X.T), sum_X).T, sum_X)
        P = np.exp(-D / (2.0 * self.perplexity))
        P = P / np.sum(P, axis=1, keepdims=True)
        return P

    def _compute_gradient(self, P, Q, Y):
        # Compute gradient for t-SNE optimization
        PQ_diff = P - Q
        grad = np.zeros_like(Y)

        for i in range(Y.shape[0]):
            grad[i, :] = 4 * np.sum(
                np.tile(PQ_diff[:, i] * P[:, i], (Y.shape[1], 1)).T * (Y[i, :] - Y), axis=0
            )

        return grad

    def transform(self, X):
        # Output the low-dimensional representation for new data
        # based on the learned transformation
        if self.Y is None:
            raise RuntimeError("The t-SNE model has not been fit yet.")
        else:
            P = self._compute_pairwise_similarities(X)
            return self._compute_gradient(P, self._compute_pairwise_similarities(self.Y), X)