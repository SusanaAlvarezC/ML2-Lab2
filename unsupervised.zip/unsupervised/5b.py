import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs

# Create scattered data
X, y = make_blobs(
    n_samples=500,
    n_features=2,
    centers=4,
    cluster_std=1,
    center_box=(-10.0, 10.0),
    shuffle=True,
    random_state=1,
)

# Plot the resulting dataset
plt.figure(figsize=(8, 6))
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis', edgecolors='k')
plt.title('Scattered Data with Four Clusters')
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show()
