import numpy as np
from sklearn import cluster, datasets, mixture
import matplotlib.pyplot as plt
from sklearn import cluster, datasets
from sklearn_extra.cluster import KMedoids


# ============
# Generate datasets. We choose the size big enough to see the scalability
# of the algorithms, but not too big to avoid too long running times
# ============


def apply_clustering(dataset, algorithms):
    X, y = dataset
    plt.figure(figsize=(len(algorithms) * 4, 4))

    for i, (name, algorithm) in enumerate(algorithms.items(), 1):
        plt.subplot(1, len(algorithms), i)
        
        if name == 'K-Medoids':
            # Correctly use KMedoids from sklearn_extra.cluster
            kmedoids = KMedoids(n_clusters=len(np.unique(y)))
            kmedoids.fit(X)
            labels = kmedoids.labels_
        else:
            # For other algorithms
            labels = algorithm.fit_predict(X)

        plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis')
        plt.title(name)

        # Print clustering results
        unique_labels = np.unique(labels)
        for cluster_label in unique_labels:
            cluster_points = X[labels == cluster_label]
            print(f"{name} - Cluster {cluster_label}: {len(cluster_points)} points")

    plt.tight_layout()
    plt.show()

n_samples = 500
noisy_circles = datasets.make_circles(n_samples=n_samples, factor=0.5, noise=0.05)
noisy_moons = datasets.make_moons(n_samples=n_samples, noise=0.05)
blobs = datasets.make_blobs(n_samples=n_samples, random_state=8)

# Anisotropically distributed data
random_state = 170
X, y = datasets.make_blobs(n_samples=n_samples, random_state=random_state)
transformation = [[0.6, -0.6], [-0.4, 0.8]]
X_aniso = np.dot(X, transformation)
aniso = (X_aniso, y)
# blobs with varied variances
varied = datasets.make_blobs(
    n_samples=n_samples, cluster_std=[1.0, 2.5, 0.5], random_state=random_state
)

# Apply clustering algorithms and compare results
algorithms = {
    'K-Means': cluster.KMeans(n_clusters=2),
    'K-Medoids': KMedoids(n_clusters=2),
    'DBSCAN': cluster.DBSCAN(eps=0.3, min_samples=5),
    'Spectral Clustering': cluster.SpectralClustering(n_clusters=2, eigen_solver='arpack', affinity="nearest_neighbors"),
}

datasets_to_compare = [noisy_circles, noisy_moons, blobs]

for dataset in datasets_to_compare:
    apply_clustering(dataset, algorithms)
