# Import necessary libraries
from clustering.KMedoids import KMedoids
from clustering.kmeans import KMeans
from sklearn.datasets import make_blobs
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt

# ============
# Calculate the silhouette coefficients for K from 1 to 5 clusters, for kmeans and kmedoids implementations
# Compares the silhouette scores through a plot.
# ============

# Generate synthetic data
X, y = make_blobs(
    n_samples=500,
    n_features=2,
    centers=4,
    cluster_std=1,
    center_box=(-10.0, 10.0),
    shuffle=True,
    random_state=1,
)

# Create a function to calculate silhouette score
def calculate_silhouette(X, labels):
    return silhouette_score(X, labels)

# Lists to store silhouette scores
kmeans_silhouette_scores = []
kmedoids_silhouette_scores = []
cluster_range = range(2, 7)

# Iterate over different numbers of clusters (K)
for K in cluster_range:  # Start from K=2
    # KMeans
    kmeans = KMeans(n_clusters=K)
    kmeans.fit(X)
    kmeans_labels = kmeans._assign_labels(X)  # Use the internal labeling method for KMeans
    kmeans_silhouette = calculate_silhouette(X, kmeans_labels)
    kmeans_silhouette_scores.append(kmeans_silhouette)
    print(f"kmeans   Cluster {K} puntaje:{kmeans_silhouette} ")  

    # KMedoids
    kmedoids = KMedoids(n_clusters=K, random_state=42)
    kmedoids.fit(X)
    kmedoids_labels = kmedoids.labels_
    kmedoids_silhouette = calculate_silhouette(X, kmedoids_labels)
    kmedoids_silhouette_scores.append(kmedoids_silhouette)  
    print(f"kmedoids Cluster {K} score :{kmedoids_silhouette} ")  

# Plotting
plt.plot(cluster_range, kmeans_silhouette_scores, label='KMeans')
plt.plot(cluster_range, kmedoids_silhouette_scores, label='KMedoids')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Silhouette Score')
plt.title('Silhouette Scores for KMeans and KMedoids')
plt.legend()
plt.show()
