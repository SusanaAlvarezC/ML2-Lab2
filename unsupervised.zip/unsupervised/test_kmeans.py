from clustering.kmeans import KMeans
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt


# Test kmeans algorithm with synthetic data

# Generate synthetic data
X, y = make_blobs(
n_samples=500,
n_features=2,
centers=4,
cluster_std=1,
center_box=(-10.0, 10.0),
shuffle=True,
random_state=1,
)


# Create and fit the custom KMeans model
kmeans = KMeans(n_clusters=4)
kmeans.fit(X)

# Predict cluster labels
labels = kmeans._assign_labels(X)

# Plot the results
plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis')
plt.scatter(kmeans.centroids[:, 0], kmeans.centroids[:, 1], marker='X', s=200, c='red', label='Centroids')
plt.legend()
plt.title('Custom KMeans Results')
plt.show()