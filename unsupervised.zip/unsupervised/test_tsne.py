from unsupervised.tsne import TSNE
import numpy as np

def test_tsne():
    # Datos de prueba
    data = np.random.rand(50, 10)

    # Crear una instancia de t-SNE
    tsne = TSNE(perplexity=30, learning_rate=200, n_iter=1000)

    # Ajustar los datos a t-SNE
    tsne.fit(data)

    # Transformar los datos
    transformed_data = tsne.transform(data)

    # Imprimir resultados
    print("Original Data:")
    print(data)
    print("\nTransformed Data:")
    print(transformed_data)

if __name__ == "__main__":
    test_tsne()
