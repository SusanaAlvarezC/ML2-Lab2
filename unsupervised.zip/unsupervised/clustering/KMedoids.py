import numpy as np
"""
 KMedoids clustering algorithm implementation.
 
 Parameters:
    - n_clusters: int, default=3
        Number of clusters.
    - tol: float, default=1e-4
        Tolerance to declare convergence.
    - random_state: int or None, default=None
        Seed for random initialization.

Methods:
    - fit(X)
        Fit the KMedoids model to the data.
"""
class KMedoids:
    def __init__(self, n_clusters=3, tol=1e-4, random_state=None):
        self.n_clusters = n_clusters
        self.tol = tol
        self.random_state = random_state
        self.labels_ = None
        self.cluster_centers_ = None

    def fit(self, X):
        np.random.seed(self.random_state)
        n_samples, n_features = X.shape

        # Initialize medoids randomly
        medoids_indices = np.random.choice(n_samples, self.n_clusters, replace=False)
        medoids = X[medoids_indices, :]

        while True:
            # Assign each sample to the nearest medoid
            distances = np.linalg.norm(X[:, np.newaxis, :] - medoids, axis=2)
            labels = np.argmin(distances, axis=1)

            # Update medoids
            new_medoids = np.empty_like(medoids)
            for i in range(self.n_clusters):
                cluster_samples = X[labels == i, :]
                costs = np.sum(np.linalg.norm(cluster_samples - cluster_samples[:, np.newaxis, :], axis=2), axis=0)
                new_medoids[i, :] = cluster_samples[np.argmin(costs), :]

            # Check for convergence
            if np.linalg.norm(new_medoids - medoids) < self.tol:
                break

            medoids = new_medoids

        self.labels_ = labels
        self.cluster_centers_ = medoids

        return self
   
  
