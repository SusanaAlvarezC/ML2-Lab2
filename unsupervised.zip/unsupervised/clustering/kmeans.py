import numpy as np
from sklearn.datasets import make_blobs
import matplotlib.pyplot as plt

"""
    KMeans clustering algorithm implementation.

    Parameters:
        - n_clusters: int
            Number of clusters.
        - tol: float, default=1e-4
            Tolerance to declare convergence.
    Methods:
    - fit(X)
        Fit the KMeans model to the data.            
"""
        
class KMeans:
    def __init__(self, n_clusters, tol=1e-4):
        self.n_clusters = n_clusters
        self.tol = tol
        self.centroids = None

    def fit(self, X):
        n_samples, n_features = X.shape

        # Initialize centroids randomly from data points
        random_indices = np.random.choice(n_samples, self.n_clusters, replace=False)
        self.centroids = X[random_indices]

        while True:
            # Assign each data point to the nearest centroid
            labels = self._assign_labels(X)

            # Update centroids based on the mean of points assigned to each cluster
            new_centroids = np.array([X[labels == k].mean(axis=0) for k in range(self.n_clusters)])

            # Check for convergence
            if np.linalg.norm(new_centroids - self.centroids) < self.tol:
                break

            self.centroids = new_centroids

        return self

    def _assign_labels(self, X):
        distances = np.linalg.norm(X[:, np.newaxis] - self.centroids, axis=2)
        return np.argmin(distances, axis=1)
